<?php

namespace App\Http\Controllers;
use App\Models\Trip;
use App\Models\booking;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Pass;

class BookingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data= Trip::all();
        // dd($data);
        return view('exprince.index',['data'=>$data]);
    }

    public function creaat(trip $data)
    {
//    dd($data);
        return view('reservtion',['data'=>$data]);
    }

    public function shower ()
    {

       return view ('driver.shower'); 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        booking::create([
            'trip_id'=>$request['trip_id'],
            'pass_id'=>$request['pass_id'],
            'driver_id'=>$request['driver_id'],
            //'epos'=>$request['epos'],
            // 'stat_place'=>$request['stat_place'],
            // 'price'=>$request['price']
            'count'=>$request['count']

        ]);
      return  redirect(route('trips.index'));
    
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\booking  $booking
     * @return \Illuminate\Http\Response
     */
    public function show(booking $booking)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\booking  $booking
     * @return \Illuminate\Http\Response
     */
    public function edit(booking $booking)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\booking  $booking
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, booking $booking)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\booking  $booking
     * @return \Illuminate\Http\Response
     */
    public function destroy(booking $booking)
    {
        
            $booking->delete();
            return back();      
        
    }
}
