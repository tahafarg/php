<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Station extends Model
{
    use HasFactory;
    protected $fillable = [
        'stat_place',
        'trip_id'
    ];
    protected $hidden =['created_at','updated_at','pivot'];
    public function trip(){
        return $this->belongsTo(Trip :: class);
    }
}
