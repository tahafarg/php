
<?php $__env->startSection('body'); ?>

 <!-- ======= Team Section ======= -->
 <section id="team" class="team section-bg">
    <div class="container" data-aos="fade-up">

      <div class="section-title">
        <h2>About Us</h2>
      </div>

      <div class="row">

        <div class="col-lg-6">
          <div class="member " data-aos="zoom-in" data-aos-delay="100">
            
            <div class="member-info">
              <h4>  El Mo2af is  all about  improveing the lives of people, saving time is our passion and simplify everyday tasks and movements , 
                We redesign the way the world moves for the better ,By providing widest choice, superior customer service, lowest prices and unmatched benefits</h4>
              
              <p> Our mission is to  Facilitate traffic or reduce congestion at peak times ,and make life much easier.
                Movement is what we power. 
                It’s what gets us out of bed each morning.
                   For you. For all the places you want to go. For all the things you want to get. 
                   For all the ways you want to earn. In real time.
                 At the incredible speed of now</p>
              
            </div>
          </div>
        </div>

        

      </div>

    </div>
  </section><!-- End Team Section -->
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ITI\laravel\final  project laravel new\final  project laravel\elmwkaf\resources\views/aboutUs.blade.php ENDPATH**/ ?>