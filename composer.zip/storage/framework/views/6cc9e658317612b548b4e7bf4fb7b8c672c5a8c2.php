
<?php $__env->startSection('body'); ?>
<main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">
        <br> <br>  <br>  
        <br> <br> 
    
        
        <h2>Sign Up As Driver</h2>
    
      </div>
    </section><!-- End Breadcrumbs -->
    
    <section class="inner-page">
      <div class="container">
        <p>
          Welcome Our Driver , Thanks For Working With Us 
        </p>
      </div>
    </section>
    
    </main><!-- End #main -->
    
    <!-- ======= Footer ======= -->
    <footer id="footer">
    
    <div class="footer-newsletter">
      <div class="container">
        <div class="row justify-content-center">
           <div class="col-lg-6">
            <form class="driverF" action="<?php echo e(route('driver.store')); ?>" method="post" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                <div class="title">
                  <i class="fas fa-pencil-alt"></i> 
                  <h2>Sign Up HERE</h2>
                </div>
                <div class="info">
                  <input class="fname" type="text" name="name" placeholder="Full name" >
                  <input type="text" name="email" placeholder="Email">
                  <input type="text" name="phone" placeholder="Phone number">
                  <input type="password" name="password" placeholder="Password">
                  <input type="age" name="age" placeholder="Age">
                  <select name="gender">
                    <option value="Gender" selected>Gender</option>
                    <option value="male">Male</option>
                    
                  </select>
    
                  <select name="city">
                    <option value="City" selected>city*</option>
                    <option value="aswan">Aswan</option>
                    
                  </select>
    
                
                
                <!--upload national phohto-->
    
                <div class="container">
                  <h3>Upload Your ID Card</h3>
                  <div class="avatar-upload">
                      <div class="avatar-edit">
                        <input type='file' id="imageUpload" name="idcard" />
                          <label for="imageUpload">
                            
                          </label>
                      </div>
                      <div class="avatar-preview">
                          <div id="imagePreview" style="background-image: url(http://i.pravatar.cc/500?img=7);">
                          </div>
                      </div>
                  </div>
              </div>
                
                
                
                
                
                
                  <!--upload profile phohto-->
    
                  <div class="container">
                    <h3>Upload Your Personal Image</h3>
                    <div class="avatar-upload">
                        <div class="avatar-edit">
                            <input type='file' id="imageUpload" name="personalImage"  />
                            <label for="imageUpload"></label>
                        </div>
                        <div class="avatar-preview">
                            <div id="imagePreview" style="background-image: url(http://i.pravatar.cc/500?img=7);">
                            </div>
                        </div>
                    </div>
                </div>
                
                
                
                
                
                
                
                
                <!--upload drive license-->
                <div class="container">
                  <h3>Upload Drive License</h3>
                  <div class="avatar-upload">
                      <div class="avatar-edit">
                          <input type='file' id="imageUpload" name="drivelicense"  />
                          <label for="imageUpload"></label>
                      </div>
                      <div class="avatar-preview">
                          <div id="imagePreview" style="background-image: url(http://i.pravatar.cc/500?img=7);">
                          </div>
                      </div>
                  </div>
              </div>
    
    
    
    
    
               <!--upload Car license-->
                       
               <div class="container">
                <h3>Upload car License</h3>
                <div class="avatar-upload">
                    <div class="avatar-edit">
                        <input type='file' id="imageUpload" name="carlicense"  />
                        <label for="imageUpload"></label>
                    </div>
                    <div class="avatar-preview">
                        <div id="imagePreview" style="background-image: url(http://i.pravatar.cc/500?img=7);">
                        </div>
                    </div>
                </div>
            </div>
       
    
    
    
    
         <!--upload drug analysis-->
         
         <div class="container">
          <h3>Upload drug analysis</h3>
          <div class="avatar-upload">
              <div class="avatar-edit">
                  <input type='file' id="imageUpload" name="druglicense"  />
                  <label for="imageUpload"></label>
              </div>
              <div class="avatar-preview">
                  <div id="imagePreview" style="background-image: url(http://i.pravatar.cc/500?img=7);">
                  </div>
              </div>
          </div>
      </div>
    
              </div>
                <div class="checkbox">
                  <input type="checkbox" name="checkbox"><span>I agree to the <a href="https://www.w3docs.com/privacy-policy">Privacy Poalicy for الموقف.</a></span>
                </div>
                <button type="submit" href="/" style="border-radius: 50px;">Sign up</button>
                                      
            </form>
           </div>
        </div>
      </div>
    </div>
    
    <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\final  project laravel\elmwkaf\resources\views/signUp/signupdriver.blade.php ENDPATH**/ ?>