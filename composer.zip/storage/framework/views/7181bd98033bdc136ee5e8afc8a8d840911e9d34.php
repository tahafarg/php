
<?php $__env->startSection('body'); ?>

	

		   					<div class="">
								
		   						<h2 class="resv">Reserve Trip With Us</h2>
			   					
			   						 
			   					
							
								   <br><br>
		   					</div>		




	
					
<div class="FORMA" >
						<div class="FRM">
							<div  class="SPPOS" >
							<section class="SPPOS2" >
                        <form method="POST" action="<?php echo e(route('trips.store')); ?>">
							<?php echo csrf_field(); ?>								
								<select class=""  name="spos">
									<option value="" disabled selected> Start Station</option>
                                    <option value="Sahaary">Sahaary</option>
									<option value="El-Sail">El-Sail</option>
									<option value="El-Nafaa">El-Nafaa</option>
									<option value="El-Korneesh">El-Korneesh</option>
									<option value="El-Taameen">El-Taameen</option>
									<option value="El-Maawkaf">El-Maawkaf</option>
									
								</select>
							</section>
							
							<section class="SPPOS2">
								<select class="" name="epos">
									<option value="" disabled selected>end station</option>
									<option value="Sahaary">Sahaary</option>
									<option value="El-Sail">El-Sail</option>
									<option value="El-Nafaa">El-Nafaa</option>
									<option value="El-Korneesh">El-Korneesh</option>
									<option value="El-Taameen">El-Taameen</option>
									<option value="El-Maawkaf">El-Maawkaf</option>
								</select>
							</section>
						</div>
							
                            
							

						
						
                        
						<div class="TIME">
							<div class="">
								<label for="time-start">Time of trip start</label>
								<input type="text" class="INTIME" id="" name="s_time">
							</div>
						</div>
						<div class="TIME">
							<div class="">
								<label for="time-end">Time of trip end</label>
								<input type="text" class="INTIME" id="" name="e_time">
							</div>
						</div>
                        
                        <div class="TIME">
							<div class="">
								<label for="time-end">price</label>
								<input type="text" class="INTIME  PRICEE" id="" name="price" >
							</div>
						</div>
                        

                        
                        
                        
                            
							
						<div class="">
							<div class="">

								<input type="submit" class="OKAY" name="submit" value="submit">
							
							</div>
						</div>
					</form>

				</div>
				</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\VERA\Desktop\PROJECT3333\final  project  home\elmwkaf\resources\views/driver/add.blade.php ENDPATH**/ ?>