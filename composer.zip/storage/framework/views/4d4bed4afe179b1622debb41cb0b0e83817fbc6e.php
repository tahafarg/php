
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>show trips</title>
    
</head>
<body >
    

    <br>
    <table class="table table-success table-striped">
        <thead>
            <tr>
                
                <th scope="col">name</th>
                <th scope="col">email</th>
                <th scope="col">password</th>
                <th scope="col">phone</th>
                
                <th scope="col">age</th>
                <th>gender</th>
                <th>city</th>
                <th>delete</th>
                
                
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                    
                    
                    <td><?php echo e($item['name']); ?></td>
                    <td><?php echo e($item['email']); ?></td>
                    <td><?php echo e($item['password']); ?></td>
                    <td><?php echo e($item['phone']); ?></td>
                    
                    
                    <td><?php echo e($item['age']); ?></td>
                    <td><?php echo e($item['gender']); ?></td>
                    <td><?php echo e($item['city']); ?></td>
                    <td><form action="<?php echo e(route('delete1',['item'=>$item])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="submit" name="submit" value="delete">
                    </form>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
      </table>




<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH C:\Users\VERA\Desktop\abl ma yboz\final  project  home\elmwkaf\resources\views/pass/index.blade.php ENDPATH**/ ?>