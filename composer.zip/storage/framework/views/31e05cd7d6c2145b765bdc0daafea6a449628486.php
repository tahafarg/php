
<?php $__env->startSection('body'); ?>
<body >
    <form method="get" action="<?php echo e(route('form')); ?>">
    <div class="btn-group" role="group" aria-label="Basic mixed styles example">
        <button type="submit" class="btn btn-success" > Add trip</button>
      </div>
    </form>
     
<!-- <a href="<?php echo e(route('trips.create')); ?>" class="btn-btn">add</a>  -->
    <br>
    <table class="table table-success table-striped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Start time</th>
                <th scope="col">End time</th>
                <th scope="col">Start place</th>
                <th scope="col">End Place</th>
                <!-- <th scope="col">Stations</th>  -->
                <th scope="col">price</th>
                <th>Delete</th>  
                <th>Edit</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                    <th scope="row">1</th>
                    <td><?php echo e($item['s_time']); ?></td>
                    <td><?php echo e($item['e_time']); ?></td>
                    <td><?php echo e($item['spos']); ?></td>
                    <td><?php echo e($item['epos']); ?></td>
                    <!--  -->
                    <td><?php echo e($item['price']); ?></td>
                    <td><form action="<?php echo e(route('trips.destroy',['trip'=>$item])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="submit" name="submit" value="delete">
                    </form>
                </td>
                    <td>
                        <form action="<?php echo e(route('trips.edit',['trip'=>$item])); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <input type="submit" name="submit" value="edit">
                    </form>
                </td>
                  </tr>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
      </table>




<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\VERA\Desktop\final  project  home\final  project  home\elmwkaf\resources\views/driver/index.blade.php ENDPATH**/ ?>