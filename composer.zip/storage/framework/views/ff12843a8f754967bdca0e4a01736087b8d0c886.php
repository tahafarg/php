
    <p><?php echo e($data['s_time']); ?></p>
    <p><?php echo e($data['e_time']); ?></p>
    <p><?php echo e($data['spos']); ?></p>
    <p><?php echo e($data['epos']); ?></p>
    <p><?php echo e($data['price']); ?></p>
 
    <?php if(auth()->guard()->check()): ?>
<br>
  
<form method="POST" action="<?php echo e(route('stations.store')); ?>">
    <?php echo csrf_field(); ?>
    <input name="trip_id" value="<?php echo e($data['id']); ?>" hidden>
    
    <select class="cs-select cs-skin-border" name="stat_place">
      <option value="" disabled selected >Stop Station</option>
      <option value="El-Raya">El-Raya</option>
      <option value="Atlas">Atlas</option>
      <option value="EL-Mahata">EL-Mahata</option>
      <option value="Masged El Naser">Masged El Naser</option>
      <option value="Abas Fareed">Abas Fareed</option>
      <option value="El-Mahkma">El-Mahkma</option>
      <option value="El-Estad">El-Estad</option>
      <option value="El-Redwan">El-Redwan</option>
      <option value="El-Karor">El-Karor</option>
      <option value="El-Meror">El-Meror</option>
</select>
    <input type="submit" name="submit" value="اضافه محطه">
</form>    
 

<?php $__currentLoopData = $data->stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 
 <form method="POST" action="<?php echo e(route('stations.update',['station'=>$item])); ?>">
    <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>

        <select class="cs-select cs-skin-border" name="stat_place">
          <option value="<?php echo e($item['stat_place']); ?>" ><?php echo e($item['stat_place']); ?></option>
          <option value="El-Raya">El-Raya</option>
          <option value="Atlas">Atlas</option>
          <option value="EL-Mahata">EL-Mahata</option>
          <option value="Masged El Naser">Masged El Naser</option>
          <option value="Abas Fareed">Abas Fareed</option>
          <option value="El-Mahkma">El-Mahkma</option>
          <option value="El-Estad">El-Estad</option>
          <option value="El-Redwan">El-Redwan</option>
          <option value="El-Karor">El-Karor</option>
          <option value="El-Meror">El-Meror</option>
    </select>
    
    <input type="submit" name="submit" value="تعديل مكان النزول">   
    </form>  
  
  <form method="POST" action="<?php echo e(route('stations.destroy',['station'=>$item])); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
<input type="submit" name="submit" value="ازاله المحطه">    
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\Users\VERA\Desktop\abl ma yboz\final  project  home\elmwkaf\resources\views/driver/show.blade.php ENDPATH**/ ?>