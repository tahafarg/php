
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>user exprince</title>
    
</head>
<body >
    <?php if(auth()->guard()->check()): ?>
    <form method="get" action="/station">
    
      
      <select class="cs-select cs-skin-border"  name="query">
        <option value="" disabled selected> Start Station</option>
        <option value="Sahaary">Sahaary</option>
        <option value="El-Sail">El-Sail</option>
        <option value="El-Nafaa">El-Nafaa</option>
        <option value="El-Korneesh">El-Korneesh</option>
        <option value="El-Taameen">El-Taameen</option>
        <option value="El-Maawkaf">El-Maawkaf</option>
        <option value="Atlas">Atlas</option>
    </select>
      <button type="submit" class="btn btn-success" >search</button>
    </form>

    <br>
    <table class="table table-success table-striped">
        <thead>
            <tr>
                
                <th scope="col">Start time</th>
                <th scope="col">End time</th>
                <th scope="col">Start place</th>
                <th scope="col">End Place</th>
                
                <th scope="col">price</th>
                
                
                
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                    
                    
                    <td><?php echo e($item['s_time']); ?></td>
                    <td><?php echo e($item['e_time']); ?></td>
                    <td><?php echo e($item['spos']); ?></td>
                    <td><?php echo e($item['epos']); ?></td>
                    
                    <td><?php echo e($item['price']); ?></td>
                    
                </td>
                <td>
                    
            </td>
                  </tr>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
      </table>


<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH C:\Users\VERA\Desktop\final  project  home111\final  project  home\elmwkaf\resources\views/exprince/index.blade.php ENDPATH**/ ?>