

<?php $__env->startSection('body'); ?>



<div class="page-content page-container" id="page-content">
    <div class="padding">
        <div class="row container d-flex justify-content-center">
            <div class="col-xl-6 col-md-12">
                <div class="card user-card-full">
                    <div class="row m-l-0 m-r-0">
                        <div class="col-sm-4 bg-c-lite-green user-profile">
                            <div class="card-block text-center text-white" >
                                <div class="m-b-25" > <img src="/storage/<?php echo e(Auth::user()->personalImage); ?> " class="img-radius" alt="User-Profile-Image" >
                                
                                <h2 >Your Profile</h2>
                                <br>
                              <button type="button" class="btn" >Edit</button>
                            
                            </div>
                            
                              
                                   <?php echo csrf_field(); ?>

                                <p > </p> <i class=" mdi mdi-square-edit-outline feather icon-edit m-t-10 f-16" ></i>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="card-block" id="card">
                                <h1 class="m-b-20 p-b-5 b-b-default f-w-600"><b>Information </b></h1>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Email</p>
                                        <?php echo e(Auth::user()->email); ?>

                                        <h6 class="text-muted f-w-400"></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Name</p>
                                        <?php echo e(Auth::user()->name); ?>

                                        <h6 class="text-muted f-w-400"></h6>
                                    </div>
                                </div>
                                <h6 class="m-b-20 m-t-40 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Phone</p>
                                        <?php echo e(Auth::user()->phone); ?>

                                        <h6 class="text-muted f-w-400"></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Age</p>
                                        <?php echo e(Auth::user()->age); ?>

                                        <h6 class="text-muted f-w-400"></h6>
                                    </div>
                                </div>
                                <h6 class="m-b-20 m-t-40 p-b-5 b-b-default f-w-600"></h6>

                                <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Gender</p>
                                        <?php echo e(Auth::user()->gender); ?>

                                        <h6 class="text-muted f-w-400"></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">City</p>
                                        <?php echo e(Auth::user()->city); ?>

                                        <h6 class="text-muted f-w-400"></h6>
                                    </div>


<br>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Car Number</p>
                                        <?php echo e(Auth::user()->carnum); ?>

                                        <h6 class="text-muted f-w-400"></h6>
                                    </div>
                                    <br>
                                    <div class="m-b-25" > <p class="m-b-10 f-w-600">Driver License</p><img src="<?php echo e(Auth::user()->driverLicense); ?> " class="img-radius" alt="User-Profile-Image" >
                                    
                                <!-- <h2 >Your Profile</h2> -->
                                <br>
                              <!-- <button type="button" class="btn" >Edit</button> -->
                            
                            </div>



                                    <!-- <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Driver License</p>
                                        <?php echo e(Auth::user()->driverLicense); ?>

                                        <h6 class="text-muted f-w-400"></h6>
                                    </div> -->
                                   
                                    <div class="m-b-25" > <p class="m-b-10 f-w-600">Car License</p><img src="<?php echo e(Auth::user()->carLicense); ?> " class="img-radius" alt="User-Profile-Image" >
                                    
                                    <!-- <h2 >Your Profile</h2> -->
                                    <br>
                                  <!-- <button type="button" class="btn" >Edit</button> -->
                                
                                </div>
                                    <!-- <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Car License</p>
                                        <?php echo e(Auth::user()->carLicense); ?>

                                        <h6 class="text-muted f-w-400"></h6>
                                    </div> -->
                                    <div class="m-b-25" > <p class="m-b-10 f-w-600">Drug Analysis</p><img src="<?php echo e(Auth::user()->drugAnalaysis); ?> " class="img-radius" alt="User-Profile-Image" >
                                    
                                <!-- <h2 >Your Profile</h2> -->
                                <br>
                              <!-- <button type="button" class="btn" >Edit</button> -->
                            
                            </div>

                                    <!-- <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Drug Analysis</p>
                                        <?php echo e(Auth::user()->drugAnalaysis); ?>

                                        <h6 class="text-muted f-w-400"></h6>
                                    </div> -->
                                  

                                    

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<br><br><br><br><br><br><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\VERA\Desktop\final  project  home111\final  project  home\elmwkaf\resources\views/driv.blade.php ENDPATH**/ ?>