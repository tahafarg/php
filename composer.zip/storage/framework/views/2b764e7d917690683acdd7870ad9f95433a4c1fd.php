
<?php $__env->startSection('body'); ?>
<main id="main">

  
    
    </main><!-- End #main -->
    
    <!-- ======= Footer ======= -->
    <footer id="footer">
    
    <div class="footer-newsletter">
      <div class="container">
        <div class="row justify-content-center">
           <div class="baack">
            <form class="main3" action="<?php echo e(route('driver.store')); ?>" method="post" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                <div class="title">
                  <i class="fas fa-pencil-alt"></i> 
                  <p class="sign3" >Sign Up</p>
                </div>
                <div class="">
                  <input  type="text" name="name"  class="un33"  placeholder="Full name" >
                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div  role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  
                  <input type="text" name="email" placeholder="Email" class="un33 here" >
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div  role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <input type="text" name="phone" placeholder="Phone number" class="un33" >
                  <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div  role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <input type="password" name="password" placeholder="Password" class="un33 here" >
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div  role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              
                  <input type="age" name="age" placeholder="Age" class="un33" >
                  <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div  role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <input type="carnum" name="carnum" placeholder="Car Number" class="un33" >
                  <?php $__errorArgs = ['carnum'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div  role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 
                  <select name="gender" class="un33"   placeholder="Gender">
                            <option name="gender" value="gender" selected>Gender</option>
                            <option value="Male">Male</option>
                            
                          </select>
                          <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div  role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                          <select name="city" class="un33"   placeholder="city">
                            <option name="city" value="City" selected>city</option>
                            <option value="aswan">Aswan</option>
                            
                          </select>
                          <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div  role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br><br>
                
                <!--upload national phohto-->
    
                <div class="container">
                  <h3  align="center">Upload Your ID Card</h3>
                  <div class="avatar-upload">
                      <div class="avatar-edit">
                        <input type='file' id="imageUpload" name="idcard" class="un3"    />
                          <label for="imageUpload">
                            
                          </label>
                          <?php $__errorArgs = ['idcard'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div  role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          
                      </div>
                      
                  </div>
              </div>
                
                
                
                
                
                
                  <!--upload profile phohto-->
    
                  <div class="container">
                    <h3  align="center">Upload Your Personal Image</h3>
                    <div class="avatar-upload">
                        <div class="avatar-edit">
                            <input type='file' id="imageUpload" name="personalImage" class="un3"  />
                            <label for="imageUpload"></label>
                            <?php $__errorArgs = ['personalImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div  role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                    </div>
                </div>
                
                
                
                
                
                
                
                
                <!--upload drive license-->
                <div class="container">
                  <h3  align="center">Upload Drive License</h3>
                  <div class="avatar-upload">
                      <div class="avatar-edit">
                          <input type='file' id="imageUpload" name="drivelicense" class="un3"   />
                          <label for="imageUpload"></label>
                          <?php $__errorArgs = ['drivelicense'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div  role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      
                      
                  </div>
              </div>
    
    
    
    
    
               <!--upload Car license-->
                       
               <div class="container">
                <h3  align="center">Upload car License</h3>
                <div class="avatar-upload">
                    <div class="avatar-edit">
                        <input type='file' id="imageUpload" name="carlicense"  class="un3" />
                        <label for="imageUpload"></label>
                        <?php $__errorArgs = ['carlicense'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div  role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                </div>
            </div>
       
    
    
    
    
         <!--upload drug analysis-->
         
         <div class="container">
          <h3 align="center">Upload drug analysis</h3>
          <div class="avatar-upload">
              <div class="avatar-edit">
                  <input type='file' id="imageUpload" name="druglicense"  class="un3" />
                  <label for="imageUpload"></label>
                  <?php $__errorArgs = ['druglicense'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div  role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              
          </div>
      </div>
    
              </div>
                <div class="boxy">
                  <input type="checkbox" name="checkbox"><span> I agree to the <a href="https://www.w3docs.com/privacy-policy">Privacy Poalicy for الموقف.</a></span>
                </div>
                <button type="submit" href="/"  class="submit3">Sign up</button>
                                      
            </form>
           </div>
        </div>
      </div>
    </div>
    
    <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\VERA\Desktop\abl ma yboz\final  project  home\elmwkaf\resources\views/signUp/signupdriver.blade.php ENDPATH**/ ?>