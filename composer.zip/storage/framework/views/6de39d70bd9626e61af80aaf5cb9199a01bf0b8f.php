
<?php $__env->startSection('body'); ?>
<main id="main">

  
    
    </main><!-- End #main -->
    
    <!-- ======= Footer ======= -->
    <footer id="footer">
    
    <div class="footer-newsletter">
      <div class="container">
        <div class="row justify-content-center">
           <div class="baack">
            <form class="main3" action="<?php echo e(route('driver.store')); ?>" method="post" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                <div class="title">
                  <i class="fas fa-pencil-alt"></i> 
                  <p class="sign3" >Sign Up</p>
                </div>
                <div class="">
                  <input  type="text" name="name"  class="un33"  placeholder="Full name" >
                  <input type="text" name="email" placeholder="Email" class="un33" >
                  <input type="text" name="phone" placeholder="Phone number" class="un33" >
                  <input type="password" name="password" placeholder="Password" class="un33" >
                  <input type="age" name="age" placeholder="Age" class="un33" >
                 
                  <select name="gender" class="un33"   placeholder="Gender">
                            <option name="gender" value="gender" selected>Gender</option>
                            <option value="Male">Male</option>
                            
                          </select>

                          <select name="city" class="un33"   placeholder="city">
                            <option name="city" value="City" selected>city</option>
                            <option value="aswan">Aswan</option>
                            
                          </select>

                
                
                <!--upload national phohto-->
    
                <div class="container">
                  <h3  align="center">Upload Your ID Card</h3>
                  <div class="avatar-upload">
                      <div class="avatar-edit">
                        <input type='file' id="imageUpload" name="idcard" class="un3"    />
                          <label for="imageUpload">
                            
                          </label>
                      </div>
                      <div class="avatar-preview">
                          <div id="imagePreview" style="background-image: url(http://i.pravatar.cc/500?img=7);">
                          </div>
                      </div>
                  </div>
              </div>
                
                
                
                
                
                
                  <!--upload profile phohto-->
    
                  <div class="container">
                    <h3  align="center">Upload Your Personal Image</h3>
                    <div class="avatar-upload">
                        <div class="avatar-edit">
                            <input type='file' id="imageUpload" name="personalImage" class="un3"  />
                            <label for="imageUpload"></label>
                        </div>
                        <div class="avatar-preview">
                            <div id="imagePreview" style="background-image: url(http://i.pravatar.cc/500?img=7);">
                            </div>
                        </div>
                    </div>
                </div>
                
                
                
                
                
                
                
                
                <!--upload drive license-->
                <div class="container">
                  <h3  align="center">Upload Drive License</h3>
                  <div class="avatar-upload">
                      <div class="avatar-edit">
                          <input type='file' id="imageUpload" name="drivelicense" class="un3"   />
                          <label for="imageUpload"></label>
                      </div>
                      <div class="avatar-preview">
                          <div id="imagePreview" style="background-image: url(http://i.pravatar.cc/500?img=7);">
                          </div>
                      </div>
                  </div>
              </div>
    
    
    
    
    
               <!--upload Car license-->
                       
               <div class="container">
                <h3  align="center">Upload car License</h3>
                <div class="avatar-upload">
                    <div class="avatar-edit">
                        <input type='file' id="imageUpload" name="carlicense"  class="un3" />
                        <label for="imageUpload"></label>
                    </div>
                    <div class="avatar-preview">
                        <div id="imagePreview" style="background-image: url(http://i.pravatar.cc/500?img=7);">
                        </div>
                    </div>
                </div>
            </div>
       
    
    
    
    
         <!--upload drug analysis-->
         
         <div class="container">
          <h3 align="center">Upload drug analysis</h3>
          <div class="avatar-upload">
              <div class="avatar-edit">
                  <input type='file' id="imageUpload" name="druglicense"  class="un3" />
                  <label for="imageUpload"></label>
              </div>
              <div class="avatar-preview">
                  <div id="imagePreview" style="background-image: url(http://i.pravatar.cc/500?img=7);">
                  </div>
              </div>
          </div>
      </div>
    
              </div>
                <div class="checkbox">
                  <input type="checkbox" name="checkbox"><span>I agree to the <a href="https://www.w3docs.com/privacy-policy">Privacy Poalicy for الموقف.</a></span>
                </div>
                <button type="submit" href="/"  class="submit3">Sign up</button>
                                      
            </form>
           </div>
        </div>
      </div>
    </div>
    
    <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ITI\laravel\final  project laravel new\final  project  home\elmwkaf\resources\views/signUP/signupdriver.blade.php ENDPATH**/ ?>