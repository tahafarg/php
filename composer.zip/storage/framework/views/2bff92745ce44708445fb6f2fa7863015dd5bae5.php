
<?php $__env->startSection('body'); ?>
    


  <div class="sidee sidebar">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="index.html">
          <i class="typcn typcn-device-desktop menu-icon"></i>
          <span class="menu-title">Dashboard</span>
          <div class="badge badge-danger">new</div>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
          <i class="typcn typcn-document-text menu-icon"></i>
          <span class="menu-title">UI Elements</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="ui-basic">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item"> <a class="nav-link" href="pages/ui-features/buttons.html">Buttons</a></li>
            <li class="nav-item"> <a class="nav-link" href="pages/ui-features/dropdowns.html">Dropdowns</a></li>
            <li class="nav-item"> <a class="nav-link" href="pages/ui-features/typography.html">Typography</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#form-elements" aria-expanded="false" aria-controls="form-elements">
          <i class="typcn typcn-film menu-icon"></i>
          <span class="menu-title">Form elements</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="form-elements">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item"><a class="nav-link" href="pages/forms/basic_elements.html">Basic Elements</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#charts" aria-expanded="false" aria-controls="charts">
          <i class="typcn typcn-chart-pie-outline menu-icon"></i>
          <span class="menu-title">Charts</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="charts">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item"> <a class="nav-link" href="pages/charts/chartjs.html">ChartJs</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#tables" aria-expanded="false" aria-controls="tables">
          <i class="typcn typcn-th-small-outline menu-icon"></i>
          <span class="menu-title">Tables</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="tables">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item"> <a class="nav-link" href="pages/tables/basic-table.html">Basic table</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#icons" aria-expanded="false" aria-controls="icons">
          <i class="typcn typcn-compass menu-icon"></i>
          <span class="menu-title">Icons</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="icons">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item"> <a class="nav-link" href="pages/icons/mdi.html">Mdi icons</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#auth" aria-expanded="false" aria-controls="auth">
          <i class="typcn typcn-user-add-outline menu-icon"></i>
          <span class="menu-title">User Pages</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="auth">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item"> <a class="nav-link" href="pages/samples/login.html"> Login </a></li>
            <li class="nav-item"> <a class="nav-link" href="pages/samples/register.html"> Register </a></li>


        </ul>
    </div>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-toggle="collapse" href="#error" aria-expanded="false" aria-controls="error">
      <i class="typcn typcn-globe-outline menu-icon"></i>
      <span class="menu-title">Error pages</span>
      <i class="menu-arrow"></i>
    </a>
    <div class="collapse" id="error">
      <ul class="nav flex-column sub-menu">
        <li class="nav-item"> <a class="nav-link" href="pages/samples/error-404.html"> 404 </a></li>
        <li class="nav-item"> <a class="nav-link" href="pages/samples/error-500.html"> 500 </a></li>
      </ul>
    </div>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="https://bootstrapdash.com/demo/polluxui-free/docs/documentation.html">
      <i class="typcn typcn-mortar-board menu-icon"></i>
      <span class="menu-title">Documentation</span>
    </a>
  </li>
</ul>
<div class="one">
<div class="content-wrapper onee" >

  <div class="card1 newsletter-card bg-gradient-warning">
      <div class="card-body">
        <div class="d-flex flex-column align-items-center justify-content-center h-100">
          <h5 class="mb-3 text-white">Driver</h5>
          <form class="form d-flex flex-column align-items-center justify-content-between w-100" action="/driv" method="GET">
            
            <button class="btn btn-danger btn-rounded mt-1" type="submit">Show</button>
          </form>
        </div>
      </div>
    </div>
</div>



<div class="content-wrapper">

<div class="card1 newsletter-card bg-gradient-warning  twoo">
    <div class="card-body">
      <div class="d-flex flex-column align-items-center justify-content-center h-100">
        <h5 class="mb-3 text-white">Passenger</h5>
        <form class="form d-flex flex-column align-items-center justify-content-between w-100" action="/pass" method="GET">
          <button class="btn btn-danger btn-rounded mt-1" type="submit">Show</button>
        </form>
      </div>
    </div>
  </div>
</div>
</div>



<div class="two">
  <div class="content-wrapper three">

    <div class="card1 newsletter-card bg-gradient-warning">
        <div class="card-body">
          <div class="d-flex flex-column align-items-center justify-content-center h-100">
            <h5 class="mb-3 text-white">Trips</h5>
            <form class="form d-flex flex-column align-items-center justify-content-between w-100" action="<?php echo e(route('trip')); ?>" method="GET">
              
              <button class="btn btn-danger btn-rounded mt-1" type="submit">Show</button>
            </form>
          </div>
        </div>
      </div>
</div>



<div class="content-wrapper four">

  <div class="card1 newsletter-card bg-gradient-warning">
      <div class="card-body">
        <div class="d-flex flex-column align-items-center justify-content-center h-100">
          <h5 class="mb-3 text-white">Booking</h5>
          <form class="form d-flex flex-column align-items-center justify-content-between w-100" method="GET" action="/book">
            
            <button class="btn btn-danger btn-rounded mt-1" type="submit">Show</button>
          </form>
        </div>
      </div>
    </div>
</div>
  </div>


</div>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\VERA\Desktop\abl ma yboz\final  project  home\elmwkaf\resources\views/adminf.blade.php ENDPATH**/ ?>