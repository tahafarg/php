<?php if(auth()->guard()->check()): ?>
<table class="table table-success table-striped">
    <thead>
        <tr>
            
            <th scope="col">Start time</th>
            <th scope="col">End time</th>
            <th scope="col">Start place</th>
            <th scope="col">End Place</th>
            
            <th scope="col">price</th>
            
            
            
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                
                
                <td><?php echo e($item['s_time']); ?></td>
                <td><?php echo e($item['e_time']); ?></td>
                <td><?php echo e($item['spos']); ?></td>
                <td><?php echo e($item['epos']); ?></td>
                
                <td><?php echo e($item['price']); ?></td>
                <td><form action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <input type="submit" name="submit" value="الغاء حجز الرحله">
                </form>
            </td>
                <td>
                     <form action="<?php echo e(route('ree',['data'=>$item])); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <input type="number" name="count" value="عدد الركاب ">
                    <input type="submit" name="submit" value="حجز الرحله">
                   
                  

                </form> 
                
            </td>
            
            <td>
                
        </td>
              </tr>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
  </table>
<?php endif; ?><?php /**PATH C:\Users\VERA\Desktop\final  project  home111\final  project  home\elmwkaf\resources\views/exprince/search.blade.php ENDPATH**/ ?>