
<?php $__env->startSection('body'); ?>
<section class="inner-page">
    <div class="container">
      <div class="container">
        <div class="container">
          <div class="row">
            
            <div id="booking" class="section">
              <div class="section-center">
                <div class="container">
                  <div class="row">
                    <div class="booking-form">
                      <div class="booking-bg">
                        <div class="form-header">
                          <h2>Booked successfully</h2>
                          <p>Your code is 160</p>
                        </div>
                      </div>
                      <form>
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group">
                              <span class="form-label">Driver Name</span>
                              <input class="form-control" type="text" value="Ahmed Ali" >
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <span class="form-label">Car info</span>
                              <input class="form-control" type="text"  value="ص و ع  2528">
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group">
                              <span class="form-label">Time of pickup</span>7
                              <input class="form-control" type="text"  value="10 am">
                              
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <span class="form-label">pickup point</span>
                              <input class="form-control" type="text"  value="el mahta">
                              
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <span class="form-label">Drop off point</span>
                          <input class="form-control" type="text"  value="hay el akkad">
                         
                        </div>
                        we will send to you a massage with this info 
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ITI\laravel\final  project laravel new\final  project  home\elmwkaf\resources\views/reservtion.blade.php ENDPATH**/ ?>