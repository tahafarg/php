
<?php $__env->startSection('body'); ?>

    <form method="get" action=" /add">
    <div class="" role="group" aria-label="Basic mixed styles example">
        <button type="submit" class="sub" > Add trips</button>
      </div>
    </form>

    <br>
    <table class="table  TAB">
        <thead>
            <tr>
                
                <th scope="col">Start time</th>
                <th scope="col">End time</th>
                <th scope="col">Start place</th>
                <th scope="col">End Place</th>
                
                <th scope="col">price</th>
                <th> Edit Trip</th>
                <th>Add Stations</th> 
                <th>show passenger</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                    
                    
                    <td><?php echo e($item['s_time']); ?></td>
                    <td><?php echo e($item['e_time']); ?></td>
                    <td><?php echo e($item['spos']); ?></td>
                    <td><?php echo e($item['epos']); ?></td>
                    
                    <td><?php echo e($item['price']); ?></td>
                   
                    <td>
                        <form action="<?php echo e(route('trips.edit',['trip'=>$item])); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <input type="submit"  class="DAF"   name="submit" value="Edit Trip">
                    </form>
                </td>
                <td>
                    <form action="<?php echo e(route('trips.show',['trip'=>$item])); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <input type="submit" class="ADDS" name="submit" value="Add stations">
                </form>
            </td>
            
            <td><form action="shower" method="POST">
                <?php echo csrf_field(); ?>
                
                <input type="submit" class="SHW" name="submit" value="show passnger">
            </form>
        </td>
                  </tr>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
      </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\VERA\Desktop\final  project  home111\final  project  home\elmwkaf\resources\views/driver/index.blade.php ENDPATH**/ ?>