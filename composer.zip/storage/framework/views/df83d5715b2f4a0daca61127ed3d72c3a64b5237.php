
<?php $__env->startSection('body'); ?>
    <?php if(auth()->guard()->check()): ?>
    <form method="get" action="/station">
        <div class="lara" id="">
            <div class="">
                <div class="form-group tm-form-element tm-form-element">
                    <div class="form-row tm-search-form-row">
                        <div class="form-group tm-form-element tm-form-element-2">                                            
    
                 <label for="spos">start place</label>
                          <select class=" form-control tm-select  SECHH"  name="query adult" id="adult">
            <option value="" disabled selected> Start Station</option>
            <option value="Sahaary">Sahaary</option>
            <option value="EL-Mahata">EL-Mahata</option>
            <option value="El-Sail">El-Sail</option>
            <option value="El-Nafaa">El-Nafaa</option>
            <option value="El-Korneesh">El-Korneesh</option>
            <option value="El-Taameen">El-Taameen</option>
            <option value="El-Maawkaf">El-Maawkaf</option>
            <option value="Atlas">Atlas</option>
        </select>
                    </div>
                    <div class="form-group tm-form-element tm-form-element-2">         
                        <div class="form-group tm-form-element tm-form-element-2">           
                        <label for="epos">end place</label>
                <select class="form-control tm-select SECHH"  name="query1 children" id="children">
            <option value="" disabled selected> Start Station</option>
            <option value="Sahaary">Sahaary</option>
            <option value="El-Sail">El-Sail</option>
            <option value="El-Nafaa">El-Nafaa</option>
            <option value="El-Korneesh">El-Korneesh</option>
            <option value="El-Taameen">El-Taameen</option>
            <option value="El-Maawkaf">El-Maawkaf</option>
            <option value="Atlas">Atlas</option>
        </select>
        </div>
                 </div>
        <br>
        <label for="time-start">Time of trip start</label>
        <input type="text" class="form-control" id="time-start" name="query2">
        
        <br>
        <label for="time-start">price</label>
        <input type="text" class="form-control" id="time-start" name="query3">
            <br>                
          <button type="submit" class="SUbh" >search</button>
                    </div></div>
                </div>
            </div>
        </div>
        </form>

<br>
    <table class="table table-success table-striped">
        <thead>
            <tr>
                
                <th scope="col">Start time</th>
                <th scope="col">End time</th>
                <th scope="col">Start place</th>
                <th scope="col">End Place</th>
                
                <th scope="col">price</th>
                
                
                
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                    
                    
                    <td><?php echo e($item['s_time']); ?></td>
                    <td><?php echo e($item['e_time']); ?></td>
                    <td><?php echo e($item['spos']); ?></td>
                    <td><?php echo e($item['epos']); ?></td>
                    
                    <td><?php echo e($item['price']); ?></td>
                    
                
                
                    
            
                  </tr>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
      </table>


<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\VERA\Desktop\abl ma yboz\final  project  home\elmwkaf\resources\views/exprince/index.blade.php ENDPATH**/ ?>