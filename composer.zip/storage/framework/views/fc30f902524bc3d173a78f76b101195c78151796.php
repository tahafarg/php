
<?php $__env->startSection('body'); ?>
<body >
		</header>
		
	</div>
	<!-- end:fh5co-header -->
	<aside id="fh5co-hero" class="js-fullheight">
		
		<div class="flexslider js-fullheight">
			<ul class="slides">
		   	<li style="background-image: url(images/best-places-to-visit-in-Aswan-1200x900.jpg);">
		   		<div class="overlay-gradient"></div>
		   		<div class="container">
		   			<div class="col-md-12 col-md-offset-0 text-center slider-text">
		   				<div class="slider-text-inner js-fullheight">
		   					<div class="desc">
								
		   						<h2>Reserve Trip With Us</h2>
			   					<p >
			   						 <a href="#" class="btn btn-primary btn-lg" id="well">Reserve Now</a>
			   					</p>
							
								   <br><br>
		   					</div>
		   				</div>
		   			</div>
		   		</div>
		   	</li>
		   	<li style="background-image: url(images/bc721480582e1a1cdce7d383886464cc.jpg);">
		   		<div class="overlay-gradient"></div>
		   		<div class="container">
		   			<div class="col-md-12 col-md-offset-0 text-center slider-text">
		   				<div class="slider-text-inner js-fullheight">
		   					<div class="desc">
		   						
		   		
	</aside>
	<div class="wrap">
		<div class="container">
			<div class="row">
				<div id="availability">
					

						<div class="a-col">
							<section>
                                <form method="POST" action="<?php echo e(route('trips.update',['trip'=>$item])); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>								
								<select class="cs-select cs-skin-border"  name="spos"  value="<?php echo e($item['spos']); ?>">
									<option value="" disabled selected> Start Station</option>
                                    <option value="Sahaary">Sahaary</option>
									<option value="El-Sail">El-Sail</option>
									<option value="El-Nafaa">El-Nafaa</option>
									<option value="El-Korneesh">El-Korneesh</option>
									<option value="El-Taameen">El-Taameen</option>
									<option value="El-Maawkaf">El-Maawkaf</option>
									
								</select>
							</section>
							<br><br>
							<section>
								<select class="cs-select cs-skin-border" name="epos"  value="<?php echo e($item['epos']); ?>">
									<option value="" disabled selected>end station</option>
									<option value="Sahaary">Sahaary</option>
									<option value="El-Sail">El-Sail</option>
									<option value="El-Nafaa">El-Nafaa</option>
									<option value="El-Korneesh">El-Korneesh</option>
									<option value="El-Taameen">El-Taameen</option>
									<option value="El-Maawkaf">El-Maawkaf</option>
								</select>
							</section>
							<br><br>
                            
							

							<br><br>
						</div>
                        
						<div class="a-col alternate">
							<div class="input-field">
								<label for="time-start">Time of trip start</label>
								<input type="text" class="form-control" id="time-start" name="s_time"  value="<?php echo e($item['s_time']); ?>">
							</div>
						</div>
						<div class="a-col alternate">
							<div class="input-field">
								<label for="time-end">Time of trip end</label>
								<input type="text" class="form-control" id="time-end" name="e_time"  value="<?php echo e($item['e_time']); ?>">
							</div>
						</div>
                        <br>
                        <div class="a-col alternate">
							<div class="input-field">
								<label for="time-end">price</label>
								<input type="text" class="form-control" id="price" name="price"  value="<?php echo e($item['price']); ?>">
							</div>
						</div>
                        

                        <hr>
                        
                        
                            
							
						<div class="a-col alternate">
							<div class="input-field">
								<label for="time-start">Edit</label>
								<input type="submit" class="form-control" name="submit" value="submit">
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	

	</div>
	<!-- END fh5co-wrapper -->
	
	<!-- Javascripts -->
	<script src="js/jquery-2.1.4.min.js"></script>
	<!-- Dropdown Menu -->
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Counters -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Owl Slider -->
	<!-- // <script src="js/owl.carousel.min.js"></script> -->
	<!-- Date Picker -->
	<script src="js/bootstrap-datepicker.min.js"></script>
	<!-- CS Select -->
	<script src="js/classie.js"></script>
	<script src="js/selectFx.js"></script>
	<!-- Flexslider -->
	<script src="js/jquery.flexslider-min.js"></script>

	<script src="js/custom.js"></script>

</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\VERA\Desktop\final  project  home111\final  project  home\elmwkaf\resources\views/driver/edit.blade.php ENDPATH**/ ?>