
<?php $__env->startSection('body'); ?>


<section id="team" class="team section-bg">
    <div class="container" data-aos="fade-up">

      <div class="section-title">
        <h2>PRIVACY & COOKIES POLICY</h2>
      </div>

      <div class="row">

        <div class="col-lg-6">
          <div class="member " data-aos="zoom-in" data-aos-delay="100">
            
            <div class="member-info">
        
              
              <p>EL Mawkaf AMBITION IS TO BE AN EXEMPLARY CORPORATE CITIZEN TO HELP MAKE THE WORLD A MORE BEAUTIFUL PLACE. 
                WE PLACE GREAT VALUE ON HONESTY AND CLARITY AND WE ARE COMMITTED TO BUILDING A STRONG 
                AND LASTING RELATIONSHIP WITH OUR CONSUMERS BASED ON TRUST AND MUTUAL BENEFIT. 
                PART OF THIS COMMITMENT MEANS SAFEGUARDING AND RESPECTING YOUR PRIVACY AND YOUR CHOICES.
                 RESPECTING YOUR PRIVACY IS ESSENTIAL TO US.
                 THIS IS WHY WE SET OUT “OUR PRIVACY PROMISE” AND OUR FULL PRIVACY POLICY BELOW.</p>
              
            </div>
          </div>
        </div>

        

      </div>

    </div>
  </section><!-- End Team Section -->














<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\ITI\laravel\final  project laravel new\final  project  home\elmwkaf\resources\views/policy.blade.php ENDPATH**/ ?>