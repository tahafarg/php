@extends('template')
@section('body')

	

		   					<div class="">
								
		   						<h2 class="resv">Reserve Trip With Us</h2>
			   					{{-- <p > --}}
			   						 {{-- <a href="#" class="" id="">Reserve Now</a> --}}
			   					{{-- </p> --}}
							
								   <br><br>
		   					</div>		




	
					{{-- <form action="#"> --}}
                      <div class="FORMA" >
						<div class="FRM">
							<div  class="SPPOS" >
				              	@auth
								<section class="SPPOS2" >
                        <form method="POST" action="{{route('trips.store')}}">
							@csrf								
								<select class=""  name="spos">
									<option value="" disabled selected> Start Station</option>
                                    <option value="Sahaary">Sahaary</option>
									<option value="El-Sail">El-Sail</option>
									<option value="El-Nafaa">El-Nafaa</option>
									<option value="El-Korneesh">El-Korneesh</option>
									<option value="El-Taameen">El-Taameen</option>
									<option value="El-Maawkaf">El-Maawkaf</option>
									{{-- @foreach ($stat as $item)
									<option value="{{$item['id']}}">{{$item['start_position']}}</option>   
									@endforeach --}}
								</select>
							</section>
							
							<section class="SPPOS2">
								<select class="" name="epos">
									<option value="" disabled selected>end station</option>
									<option value="Sahaary">Sahaary</option>
									<option value="El-Sail">El-Sail</option>
									<option value="El-Nafaa">El-Nafaa</option>
									<option value="El-Korneesh">El-Korneesh</option>
									<option value="El-Taameen">El-Taameen</option>
									<option value="El-Maawkaf">El-Maawkaf</option>
								</select>
							</section>
						</div>
							
                            
							{{-- <section>
								<select class="cs-select cs-skin-border" name="stat_place" multiple>
									<option value="" disabled selected >Stop Station</option>
									<option value="El-Raya">El-Raya</option>
									<option value="Atlas">Atlas</option>
									<option value="EL-Mahata">EL-Mahata</option>
									<option value="Masged El Naser">Masged El Naser</option>
									<option value="Abas Fareed">Abas Fareed</option>
									<option value="El-Mahkma">El-Mahkma</option>
									<option value="El-Estad">El-Estad</option>
									<option value="El-Redwan">El-Redwan</option>
									<option value="El-Karor">El-Karor</option>
									<option value="El-Meror">El-Meror</option>

								</select>
							</section>
                             --}}

						
						
                        
						<div class="TIME">
							<div class="">
								<label for="time-start">Time of trip start</label>
								<input type="text" class="INTIME" id="" name="s_time">
							</div>
						</div>
						<div class="TIME">
							<div class="">
								<label for="time-end">Time of trip end</label>
								<input type="text" class="INTIME" id="" name="e_time">
							</div>
						</div>
                        
                        <div class="TIME">
							<div class="">
								<label for="time-end">price</label>
								<input type="text" class="INTIME  PRICEE" id="" name="price" >
							</div>
						</div>
                        

                        
                        {{-- <h1>stations</h1> --}}
                        
                            {{-- @csrf
                            <select class="cs-select cs-skin-border" name="st_id">
                                <option value="" multiable>Stop Station</option>
                               @foreach ($data as $item)
                                <option value="{{$item['id']}}">{{$item['name']}}</option>   
                                @endforeach
                             </select>
                            <input type="text" name="price">
                            <input type="submit" name="submit" value="add" >
                        </form>
						<div class="a-col action"> --}}
							
						<div class="">
							<div class="">

								<input type="submit" class="OKAY" name="submit" value="submit">
							
							</div>
						</div>
					</form>

				</div>
			</div>
			@endauth
@endsection