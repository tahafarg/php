@extends('template')
{{-- @auth --}}
@section('body')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <!-- <div class="card"> -->
                <div class="card-header">{{ __('Register') }}</div>

                <div class="card-header main">
                    <form class="form" method="POST" action="{{route('register')}}">
                        @csrf
                        <p class="sign" align="center">Sign Up</p>
                          {{-- name  --}}
                        <div class=" mb-3">
                            <!-- <label for="name" class="col-md-4 col-form-label text-md-end">{{ __('Name') }}</label> -->

                            <div class="col-md-6">
                                <input id="name" class="un" type="text" align="center" placeholder="Name"
                                @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>


                                      {{-- phone  --}}

                        <div class=" mb-3">
                            <!-- <label for="phone" class="col-md-4 col-form-label text-md-end">{{ __('phone') }}</label> -->

                            <div class="col-md-6">
                                <input id="phone" type="text" class="un" type="text" align="center" placeholder="Phone"
                                @error('phone') is-invalid @enderror" name="phone" value="{{ old('phone') }}" required autocomplete="phone" autofocus>

                                @error('phone')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                                 {{-- age  --}}
                        <div class=" mb-3">
                            <!-- <label for="age" class="col-md-4 col-form-label text-md-end">{{ __('age') }}</label> -->

                            <div class="col-md-6">
                                <input  name="age" id="age" type="text" class="un" type="text" align="center" placeholder="Age">

                                {{-- @error('age')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror 
                            </div>
                        </div>

                        
                                      {{-- email  --}}
                        <div class=" mb-3">
                        <input class="un" type="email" align="center" placeholder="email" @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
                      @error('email')
                      <span class="invalid-feedback" role="alert">
                          <strong>{{ $message }}</strong>
                      </span>
                 
                                @enderror
                            </div>
                        </div>


                          {{-- password  --}}
                        <div class=" mb-3">

                            <div class="col-md-6">
                            <input class=" un" type="password" align="center" placeholder="Password"@error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                                 {{-- confirm pass  --}}
                        <div class=" mb-3">
                            <!-- <label for="password-confirm" class="col-md-4 col-form-label text-md-end">{{ __('Confirm Password') }}</label> -->

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="un" type="text" align="center" placeholder="Confirm Password" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <select name="gender" class="un"  align="center" placeholder="Gender">
                            <option name="gender" value="gender" selected>Gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            
                          </select>

                          <select name="city" class="un"  align="center" placeholder="city">
                            <option name="city" value="City" selected>city</option>
                            <option value="aswan">Aswan</option>
                            
                          </select>

                        <div class=" mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="submit2">
                                    {{ __('Register') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
