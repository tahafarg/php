@extends('template')
@section('body')

<section class="inner-page">
    <div class="container">
      <div class="container">
        <div class="container">
          <div class="row">
            {{-- {{dd($data)}} --}}
            <div id="booking" class="section">
              <div class="section-center">
                <div class="container">
                  <div class="row">
                    <div class="booking-form">
                      <div class="booking-bg">
                        <div class="form-header">
                          <h2>Booked successfully</h2>
                          {{-- <p>Your code is 160</p> --}}
                        </div>
                      </div>
                      <form>
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group">
                              <span class="form-label">Driver Name</span>
                              <input class="form-control" type="text" value="{{$data->driver->user['name']}}"readonly >
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <span class="form-label">Car info</span>
                              <input class="form-control" type="text"  value="{{$data->driver['carnum']}}" readonly>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group">
                              <span class="form-label">Time of pickup</span>7
                              <input class="form-control" type="text"  value="{{$data->s_time}}" readonly>
                              
                            </div>
                            <div class="col-md-6">
                              <div class="form-group">
                                <span class="form-label">Time of dorp off</span>
                                <input class="form-control" type="text"  value="{{$data->e_time}}" readonly>
                                
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <span class="form-label">pickup point</span>
                              <input class="form-control" type="text"  value="{{$data->spos}}" readonly>
                              
                            </div>
                          </div>
                         
                          <div class="form-group">
                           <span class="form-label">Drop off point</span>
                           <input class="form-control" type="text"  value="{{$data->epos}}" readonly>
                           </div>

                           <div class="form-group">
                            <span class="form-label">Price</span>
                            <input class="form-control" type="text"  value="{{$data->price}}" readonly>
                            </div>
                           
                        we will send to you a massage with this info 
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>


@endsection