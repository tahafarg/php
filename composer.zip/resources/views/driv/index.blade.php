
<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>show trips</title>
    {{-- <style>
        body {
           background-image: url("C:\Users\TAHA\Desktop\php laravel\iti\public\images\as.jpg");
        }
     </style> --}}
</head>
<body >
    {{-- <form method="get" action="{{route('trips.create')}}">
    <div class="btn-group" role="group" aria-label="Basic mixed styles example">
        <button type="submit" class="btn btn-success" >أضافه رحله</button>
      </div>
    </form> --}}
{{--     
<a href="{{route('trips.create')}}" class="btn-btn">add</a> --}}
    <br>
    <table class="table table-success table-striped">
        <thead>
            <tr>
                {{-- <th scope="col">#</th> --}}
                <th scope="col">name</th>
                <th scope="col">email</th>
                <th scope="col">password</th>
                <th scope="col">phone</th>
                {{-- <th scope="col">Stations</th> --}}
                <th scope="col">age</th>
                <th>gender</th>
                <th>city</th>
                <th>delete</th>
                <th>show</th>
                {{-- <th>acsepted</th>
                <th>rejacted</th> --}}
                {{-- <th>تعديل الرحله</th>
                <th>اضافه محطات</th>  --}}
            </tr>
            </thead>
            <tbody>
                @foreach ($data as $item)
                   <tr>
                    {{-- <th scope="row">{{$item['id']}}</th> --}}
                    {{-- <th scope="row">1</th> --}}
                    <td>{{$item->User['name']}}</td>
                    <td>{{$item->User['email']}}</td>
                    <td>{{$item->User['password']}}</td>
                    <td>{{$item->User['phone']}}</td>

                    {{-- <td>{{$item['stat_place']}}</td> --}}
                    
                    <td>{{$item->User['age']}}</td>
                    <td>{{$item->User['gender']}}</td>
                    <td>{{$item->User['city']}}</td>
                    <td>
                        <form action="{{route('delete2',['pass'=>$item])}}" method="POST">
                        @csrf
                        @method('DELETE')
                        <input type="submit" name="submit" value="delete">
                    </form></td>
                    <td>
                    <form action="{{route('show',['pass'=>$item])}}" method="get">
                        @csrf
                        <input type="submit" name="submit" value="show">
                    </form>
                </td>
                    {{-- 
                <td><form method="POST" action="/accept/{{$item['id']}}">
                    @csrf 
                    @method('PUT') 
                    <input type="submit" name="submit" value="ACCEPT" class="btn btn-success" >
                  </form></td>
                  
                <td><form method="POST" action="/rejected/{{$item['id']}}">
                    @csrf 
                    @method('PUT') 
                    <input type="submit" name="submit" value="REJECTED" class="btn btn-denger" >
                  </form></td>
                  </tr>   --}}
                @endforeach
            </tbody>
      </table>




<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</body>
</html>
