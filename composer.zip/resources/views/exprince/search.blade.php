@auth
<table class="table table-success table-striped">
    <thead>
        <tr>
            {{-- <th scope="col">#</th> --}}
            <th scope="col">Start time</th>
            <th scope="col">End time</th>
            <th scope="col">Start place</th>
            <th scope="col">End Place</th>
            {{-- <th scope="col">Stations</th> --}}
            <th scope="col">price</th>
            {{-- <th>الغاء الرحله</th>
            <th>حجز الرحله</th> --}}
            
            
        </tr>
        </thead>
        <tbody>
            @foreach ($result as $item)
               <tr>
                {{-- <th scope="row">{{$item['id']}}</th> --}}
                {{-- <th scope="row">1</th> --}}
                <td>{{$item['s_time']}}</td>
                <td>{{$item['e_time']}}</td>
                <td>{{$item['spos']}}</td>
                <td>{{$item['epos']}}</td>
                {{-- <td>{{$item['stat_place']}}</td> --}}
                <td>{{$item['price']}}</td>
                <td><form action="{{--{{route('showbook.destroy',['booking'=>])}}--}}" method="POST">
                    @csrf
                    @method('DELETE')
                    <input type="submit" name="submit" value="الغاء حجز الرحله">
                </form>
            </td>
                <td>
                     <form action="{{route('ree',['data'=>$item])}}" method="get">
                    @csrf
                    <input type="number" name="count" value="عدد الركاب ">
                    <input type="submit" name="submit" value="حجز الرحله">
                   
                  

                </form> 
                
            </td>
            
            <td>
                {{-- <form action="{{route('trips.show',['trip'=>$item])}}" method="get">
                @csrf
                <input type="submit" name="submit" value="عرض محطات">
            </form> --}}
        </td>
              </tr>  
            @endforeach
        </tbody>
  </table>
@endauth